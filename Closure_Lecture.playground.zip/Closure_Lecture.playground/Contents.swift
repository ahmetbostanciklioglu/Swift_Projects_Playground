import UIKit
import Foundation

//MARK: - Completion Callback Method
var shoppingList = ["key": "value"]

func callSomeMethodWithParams(_ parameters: [AnyHashable: Any], onSuccess success: @escaping (_ JSON: Any) -> Void,
                              onFailure failure: @escaping (_ error: Error?, _ parameters: [AnyHashable: Any]) -> Void) {
    
    print("\n" + String(describing: parameters))
    
    let error: Error? = NSError(domain: "", code: 1, userInfo: nil)
    var responseArrays: [Any]?
    responseArrays = [1, 2, 3, 4, 5]
    
    if let responseArray = responseArrays {
        success(responseArray)
    }
    if let error = error {
        failure(error, parameters)
    }
    
}


callSomeMethodWithParams(shoppingList, onSuccess: { JSON in
    print("\nSuccess. Response received...: " + String(describing: JSON))
}) { (error, parameters) in
    if let error = error {
        print("\nError: " + error.localizedDescription)
    }
    print("\nParameters passed are: " + String(describing: parameters))
}




//MARK: - Return a closure from a function

var addClosure: (Int, Int) -> Int = { $0 + $1 }

func returnClosure() -> (Int, Int) -> Int {
    return addClosure
}

returnClosure()(10, 20)  // returns 30

var returnedClosure = returnClosure() // returns a closure of type (Int,Int)->Int

returnedClosure(20, 10) // returns 30



//MARK: - Initialize or customize objects using closures

//Example - 1
func setupView() -> UIView {
    
    let view = UIView()
    view.backgroundColor = .red
    
    return view
}

let someView = setupView() // returns a red view

//Example - 2
let setupViewUsingClosure = { () -> UIView in
    let view = UIView()
    
    view.backgroundColor = .green
    return view
}

let someOtherView = setupViewUsingClosure() // returns a green view

//Example - 3

let setupViewUsingClosure2: UIView = {
    let view = UIView()
    view.backgroundColor = .green
    return view
}()

//MARK: - A closure
let aClosure = { "hello, I'm a closure."}  // In the first statement, aClosure is actually a closure of type ()->String
print(aClosure())


//MARK: - A closure call
let aString = { "hello, I am a closure too."}() // IN the second statement, we added () at the end .So it became a closure call. So, it executes the closure and returns a String . If it is not clear, refer the Inferred type closure section above.

print(aString)



//MARK: -  Trailing Closures
///If you need to pass a closure expression to a function as the function’s final argument and the closure expression is long, it can be useful to write it as a trailing closure instead. A trailing closure is written after the function call’s parentheses, The argument label onSuccess is not there in the function call. Even though the closure is included in the function parameters list, swift will take it out of the parameter block to make the code more readable.
func doSomething(number: Int, onSuccess closure:(Int) -> Void) {
   closure(number * number * number)
}

doSomething(number: 10) { numberCube in
    print(numberCube)
}

doSomething(number: 11) { (numberCube) in
    print(numberCube)
}




//MARK: - Capturing values


// Capturing
var i = 0
var closureArray = [()-> ()]()

for _ in 1...5 {
    closureArray.append {
        print(i)
    }
    
    i += 1
}

// here i will be 5
closureArray[0]()
closureArray[1]()
closureArray[2]()
closureArray[3]()
closureArray[4]()




// Capturing list
var closureArray2 = [() -> ()]()
var j = 0
var k = 1
var l = 2

for _ in 1...5 {
    
//    1. part
//    closureArray2.append { [j] in
//    print(j)
//    }
//    or use
    
//    2. part
//    closureArray2.append { [j,k,l] in
//    print("\(j) \(k) \(l)")
//    }
    

//    3. part
    closureArray2.append { [a = j, b = k, c = l] in
        print("\(a) \(b) \(c)")
    }
    
    j += 1
    k += 1
    l += 1
}

// here i will be 5

closureArray2[0]()
closureArray2[1]()
closureArray2[2]()
closureArray2[3]()
closureArray2[4]()



//MARK: - Escaping closure vs non-escaping closure

///An escaping closure is a closure that’s called after the function it was passed to returns. In other words, it outlives the function it was passed to.
///A non-escaping closure is a closure that’s called within the function it was passed into, i.e. before it returns.


func someFunctionWithNonescapingClosure(closure: () -> Void) {
    
    closure()
}

func someFunctionWithEscapingClosure(completionHandler: @escaping () -> Void) {
    
    completionHandler()
    
}

class SomeClass {
    var x = 10
    
    func doSomething() {
        
        someFunctionWithEscapingClosure {
            self.x = 100
        }
        
        someFunctionWithNonescapingClosure {
            x = 200
        }
    }
}



//MARK: - Memory management

///A strong reference cycle occurs when two objects keep a strong reference of each other. Because of this cycle, the two objects won’t be deallocated, since their reference count doesn’t drop to zero. By default, a closure keeps a strong reference of the variable captured.

class InterviewTest {
    var name: String = "Ahmet"
   
    //MARK: - Closure Call
    lazy var greeting: String = {
        return "Hello \(self.name)"
    }()
}

let testObj = InterviewTest()
testObj.greeting
print(testObj.greeting)

///The lazy var greeting is returning a string by accessing the local variable name from the class InterviewTest . We cannot directly access the variable. We have to use self keyword to do that. But as explained, by default, a closure keeps a strong reference of the variable captured. It may cause reference cycles.



/// ** We can break this  , closure call , strong reference cycle using self in the capture list with either a weak or an unowned reference.**/


//MARK: - weak
///A weak reference is a reference that does not keep a strong hold on the instance it refers to, and so does not stop ARC from disposing of the referenced instance. This behavior prevents the reference from becoming part of a strong reference cycle.
///Since a weak reference may be nil, the variable captured becomes optional. Therefore, we should use a guard to safely unwrap it:

//var greeting: String = { [weak self] in
//
//    var name = "Ahmet"
//    guard let strongSelf = self else {
//        return ""
//    }
//    return "Hello \(strongSelf.name)"
//
//}()


//MARK: - Unowned
/// Like a weak reference, an unowned reference does not keep a strong hold on the instance it refers to. Unlike a weak reference, however, an unowned reference is used when the other instance has the same lifetime or a longer lifetime

//var greeting: String = { [unowned self] in
//return “Hello \(self.name)”
//
//}()



class HumanWithUnowned {
    var firstName: String
    var lastName: String
    
    lazy var fullName: (String) -> String = { [unowned self] titlePrefix in
        return "\(titlePrefix).\(self.firstName) \(self.lastName)"
    }
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    deinit {
        print("De-allocating the Human object named \(firstName) \(lastName)")
    }
}

var humanObj: HumanWithUnowned? = HumanWithUnowned(firstName: "Ahmet", lastName: "Bostancı")
let fullName = humanObj?.fullName("Mr")

humanObj = nil



class HumanWithWeakSelf {
    var firstName: String
    var lastName: String
    
    lazy var fullName: (String) -> String = { [unowned self] titlePrefix in
        return "\(titlePrefix).\(self.firstName) \(self.lastName)"
    }
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    deinit {
        print("De-allocating the Human object named \(firstName) \(lastName)")
    }
}

var humanObj2: HumanWithWeakSelf? = HumanWithWeakSelf(firstName: "Ali", lastName: "Bostancı")
let fullName2 = humanObj?.fullName("Mr")

humanObj2 = nil



//MARK: - Autoclosures

var customerInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

print(customerInLine.count)


let customerProvider = { customerInLine.remove(at: 0)} // // this is of type ()->String

print(customerProvider())


func serve(customer customerProvider: () -> String) {
    
    print("Now serving \(customerProvider())!")
    
}
 
//serve(customer: { customerInLine.remove(at: 0)}) // Prints "Now serving Alex!" // we cannot omit {}

serve {
    customerInLine.remove(at: 0)
}

func serve2(customer customerProvider: @autoclosure () -> String ) {
    
    print("Now serving \(customerProvider())!")
    
}
serve2(customer: customerInLine.remove(at: 0))



//Second Example


//extension UIView {
//    class func animate(withDuration duration: TimeInterval, _ animations: @escaping @autoclosure () -> Void) {
//        UIView.animate(withDuration: duration, animations: animations)
//    }
//}
//
////UIView.animate(withDuration: 2.5) {
////    self.view.bacgrodColor = .orange
////}
//
////OR
//
//UIView.animate(withDuration: 2.5,  self.view.backgroundColor = .orange)
