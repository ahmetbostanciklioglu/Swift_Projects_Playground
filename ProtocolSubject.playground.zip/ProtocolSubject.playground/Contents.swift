import UIKit

var greeting = "Hello, playground"


protocol WeatherReports {
    mutating func weather()
}

enum WeatherChecking: WeatherReports {
    case sunny, rain

    mutating func weather() {
        switch self {
        case .sunny:
            self = .sunny
        case .rain:
            self = .rain
        
        }
    }
}


var checking = WeatherChecking.rain

checking.weather()



///The required modifier before the definition of a class initializer to indicate that every subclass of the class must implement that initializer
///The use of the required modifier ensures that you provide an explicit or inherited implementation of the initializer requirement on all subclasses of the conforming class, such that they also conform to the protocol.


protocol Details {
    init(id: String, name: String)
}

class StudentDetails: Details {
    var id: String
    var name: String
    required init(id: String, name: String) {
        self.id = id
        self.name = name
        
    }
}


var detailsObject = StudentDetails(id: "cs106", name: "Ahmet")
print(detailsObject.id, detailsObject.name)



protocol TotalMark {
    func calculatingTotalMark()
}

protocol Percentage {
    func calculatingPercentage()
}

protocol StudentDetails2: TotalMark, Percentage {
    func printingDetails()
}

class ProtocolAdoptsToClass: StudentDetails2 {
    func printingDetails() {
        print("Adoption from StudentDetails2")
    }
    
    func calculatingTotalMark() {
        print("Adoption from TotalMark")
    }
    
    func calculatingPercentage() {
        print("Adoption from Percentage")
    }
    
    
}


///You can limit protocol adoption to class types by adding the AnyObject protocol to a protocol’s inheritance list.

protocol StudentDetails3: AnyObject, TotalMark, Percentage {
    func printingDetails()
}

///If a non -class type tries to conform to this protocol, the compiler throws an error.


protocol StudentName {
    var name: String { get set }
}
protocol StudentAge {
    var age : Int { get set }
}
struct StudentDetails4: StudentName, StudentAge {
      var name: String
      var age: Int
}
func printingDetails(details: StudentName & StudentAge ) {
    print(details.name, details.age)
}
var student = StudentDetails4(name: "Ahmet",age: 23)
printingDetails(details: student)



protocol StudentName5 {
    var name: String { get  }
    var lastName: String { get set }
}

extension StudentName5 {
    func age() -> String {
        return "26"
    }
}

struct StudentDetails5: StudentName5 {

    var name = "Ali"  /// In here we are reading (get ) name variable which is adopted from StudentName5 protocol
    var lastName = "Mert"
}

var student3: StudentDetails5 = StudentDetails5()

student3.name = "Ahmet" ///In here we are writing  (set) name variable which is adopted from StudentName5 protocol
print(student3.age())   ///In here we are writing  (set) name variable which is adopted from StudentName5 protocol
student3.lastName = "Metin"



let names = ["dhoni","kohil","sachin"]
extension Collection {
    func summarize()
    {
        for name in self {
            print(name)
        }
    }
}
print(names.summarize())





protocol VoiceAssistant {
    var name: String { get }  ///When  we use { get set }  name property in Siri struct have to  define as a variable (var)
    var voice: String { get set }
    var version: String { get }  // add here set so { get set } will be
}

struct Siri: VoiceAssistant {
    ///Type 'Siri' does not conform to protocol 'VoiceAssistant'
    let name = "Siri"   ///Candidate is not settable, but protocol requires it
    var voice = "Vicky"
    var version = "1.0"
}

var myVoiceAssistant: VoiceAssistant = Siri()

myVoiceAssistant.voice = "Samantha"
//myVoiceAssistant.name = "Ali"
//myVoiceAssistant.version = "2.0"  ///Cannot assign to property: 'version' is a get-only property
