import UIKit

var greeting = "Hello, playground"


///Example - 1
enum ErrorsToThrow: Error {
    case fileNotFound
    case fileNotReadable
    case fileSizeIsTooHigh
}

//func readFiles(path: String) throws -> String {
//
//    if fileNotFound {
//        throw ErrorsToThrow.fileNotFound
//    } else if fileNotReadable {
//        throw ErrorsToThrow.fileNotReadable
//    } else if fileSizeIsTooHigh {
//        throw ErrorsToThrow.fileSizeIsTooHigh
//    }
//    return "Data from file"
//}
//

//func canThrowErrors() throws -> String
//func cannotThrowErrors() -> String



///Example - 2

enum ErrorsToThrow2: Error {
    case nameIsEmpty
}

class Human {
    var name: String?
    
    init(name: String?) throws{
        guard let name = name else {
            throw ErrorsToThrow2.nameIsEmpty
        }
        self.name = name
    }
    
}


//MARK: - try vs try! vs try?

///try is only used within a do-catch block. However, try? and try! can be used without it.,


//— try? returns an optional type. It can be used without a do-catch block. If the method of initializer throws an error, the result will be nil.


//MARK: - try
do {
    _ = try Human(name: nil)
} catch ErrorsToThrow2.nameIsEmpty {
    print("The name is empty. Cannot initialize human")
}


//MARK: - try?
let humanObj1 = try? Human(name: "He-man")
print(humanObj1?.name! ?? "")
let humanObj2 = try? Human(name: nil)


//MARK: - try!
///try! It returns a normal type. If the method/init throws an error, it will crash. Because the returned type will be nil and a normal type cannot handle nil.
let humanObj3 = try! Human(name: "He-man")
print(humanObj3.name!)

let humanObj4 = try! Human(name: nil)  // nil and the app will crash




//Full Example:
//enum ErrorsToThrow: Error {
//    case nameIsEmpty
//}
//
//
//class Human {
//    var name: String?
//
//    init(name: String?) throws {
//        guard let name = name else {
//            throw ErrorsToThrow.nameIsEmpty
//        }
//        self.name = name
//    }
//}
//
//
////MARK:   do-try-catch
//do {
//    let humanObj = try Human(name: nil)
//} catch  ErrorsToThrow.nameIsEmpty {
//    print("The name is empty. Cannot initialize human")
//}
//
//
////MARK: - try?
//let humanObj1 = try? Human(name: "He-man")
//print(humanObj1?.name! ?? "")
//let humanObj2 = try? Human(name: nil)
//print(humanObj2?.name)
//
////MARK: - try!
//let humanObj3 = try! Human(name: "Super-man")
//print(humanObj3.name!)
////let humanObj4 = try! Human(name: nil)
