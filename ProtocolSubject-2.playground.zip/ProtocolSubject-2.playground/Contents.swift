import UIKit

var greeting = "Hello, playground"

protocol FullyNamed {
    var fullName: String { get }
}

struct Person: FullyNamed {
    var fullName: String /// fullName is a stored property
}
let john = Person(fullName: "John Appleased")

struct Person2: FullyNamed {
    var fullName: String {
        ///fullName is a computed property
        return "John Appleased"
    }
}
let john2 =  Person2()
john2.fullName


protocol MethodRequirements {
    func someMethod()
    func someMethodWithReturnType() -> String
    static func someStaticMethod(variadicParam: String...)
}

struct SomeStruct: MethodRequirements {
    func someMethod() {
        print("someMethod called")
    }
    
    func someMethodWithReturnType() -> String {
        print("someMethodWithReturnType called")
        return "return something"
    }
    
    static func someStaticMethod(variadicParam: String...) {
        print(variadicParam)
    }
}

let structObj = SomeStruct()  ///SomeStruct() is an instance
structObj.someMethod()
structObj.someMethodWithReturnType()
SomeStruct.someStaticMethod(variadicParam: "1", "2", "3")


class SomeClass: MethodRequirements {
    func someMethod() {
        print("someMethod called")
    }
    
    func someMethodWithReturnType() -> String {
        print("someMethodWithReturnType called")
        return "return something"
    }
    
    class func someStaticMethod(variadicParam: String...) {
        /// you can write class or static before func keyword
        print(variadicParam)
    }
}

let classObj = SomeClass() ///SomeClass() is an instance
classObj.someMethod()
classObj.someMethodWithReturnType()
SomeClass.someStaticMethod(variadicParam: "1", "2", "3")



protocol Togglable {
    mutating func toogle()
}

enum OnOffSwitch: Togglable {
case off, on
    mutating func toogle() {
        switch self {
        case .off:
            self = .on
        case .on:
            self = .off
        }
    }
}

var lightSwitch = OnOffSwitch.off
lightSwitch.toogle()

class ToogleClass: Togglable {
    var someBool = false
    func toogle() {
        someBool = true
    }
}

let toggleClassObj = ToogleClass()
toggleClassObj.toogle()
print("somebool is = \(toggleClassObj.someBool)")




protocol SomeProtocol {
    init()
}

class SomeSuperClass {
    init() {
        
    }
}

class SomeSubClass: SomeSuperClass, SomeProtocol {
    ///// "required" from SomeProtocol conformance; "override" from SomeSuperClass
    required override init() {
    }
    
}



protocol CallBackDelegate {
    func somethingHappened()
}
class Class1 {
    var delegate: CallBackDelegate?
    func doSomething() {
        delegate?.somethingHappened()
    }
}

class Class2: CallBackDelegate {
  
    func somethingHappened() {
        print("something happened calback called")
    }
}
let class1 = Class1()
let class2 = Class2()
class1.delegate = class2
class1.doSomething()


protocol Growable {
    var age: Int? { get }
}
class Human {
    var name: String?
    var weight: Float?
}

extension Human: Growable {
    var age: Int? {
        return 10
    }
}

let humanObj = Human()
humanObj.age


class Animal {
    var age: Int? {
        return 10
    }
}

extension Animal: Growable { }

let animalObj = Animal()
let humanObj2 = Human()

let growableArray: [Growable] = [humanObj2, animalObj]
growableArray.map { print($0.age) }



///Class-Only Protocols
///You can limit protocol adoption to class types (and not structures or enumerations) by adding the AnyObject or class protocol to a protocol’s inheritance list.

///protocol SomeClassOnlyProtocol: AnyObject, SomeInheritedProtocol { }

func printAgeOfAnimal(animal: Animal & Growable) {
    print(animal.age)
}
printAgeOfAnimal(animal: animalObj)


protocol Rotating {
    var rotates: Bool { get }
}
extension Rotating {
    var rotates: Bool {
        return true
    }
}

class Fan: Rotating { }

let fanObj = Fan()
fanObj.rotates


extension Array where Element: Equatable {
    static func ==(lhs: Array<Element>, rhs: Array<Element>) -> Bool {
        return lhs == rhs
    }
}
