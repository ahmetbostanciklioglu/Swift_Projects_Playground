import UIKit

var greeting = "Hello, playground"


class Fruit {
    var name: String? = "Banana"
    
    deinit {
        print("Freeing up the Fruit")
    }
}

var banana: Fruit = Fruit()

//banana.name = nil


class Pet {
    let name: String
    weak  var owner: Owner?
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("Pet deallocated")
    }
}


class Owner {
    let name: String
    var pet: Pet?
    
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("Owner deallocated")
    }
}

var pet: Pet? = Pet(name: "Dog")
var owner: Owner? = Owner(name: "Alice")


pet!.owner = owner
owner!.pet = pet

//print(pet)
//print(owner)

pet = nil
owner = nil

//print(pet)
//print(owner)
