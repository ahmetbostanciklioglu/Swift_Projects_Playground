import UIKit

var greeting = "Hello, playground"



let serialQueue = DispatchQueue(label: "customSerialQueue")

for i in 0...3 {
    serialQueue.sync {
        sleep(UInt32(3-i))
        print(i)

    }
}

print("NSIstanbul")

let concurrentQueueu = DispatchQueue(label: "customconcurrentQueue", attributes: .concurrent)


for j in 0...3 {

    concurrentQueueu.async {
        sleep(UInt32(3-j))
        print(j)
    }
}
print("NSIstanbul")


for j in 0...3 {

    concurrentQueueu.sync {
        sleep(UInt32(3-j))
        print(j)
    }
}
print("NSIstanbul")

for i in 0...3 {
    DispatchQueue.main.async {
        sleep(UInt32(3-i))
        print(i)
    }
}
print("NSIstanbul")


for i in 0...3 {
    DispatchQueue.main.async {
        sleep(UInt32(3-i))
        print(i)
    }
}
print("NSIstanbul")


//let queue = DispatchQueue(label: "CustomQueue")
//
//queue.async {
//    let smallImage = image.resize(to: rect)
//
//    DispatchQueue.main.async {
//        UIImageView.image = smallImage
//    }
//
//}
