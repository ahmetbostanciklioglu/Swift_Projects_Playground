import UIKit

var greeting = "Hello, playground"

func printMyInt(par: Int) {
    print(" my Int is \(par)")
}

func printMyDouble(par: Double) {
    print(" my Double is \(par)")
}

func printMyString(par: String) {
    print(" my String is \(par)")
}

printMyInt(par: 5)
printMyDouble(par: 5.75)
printMyString(par: "You are good")




//MARK: - Using Generics Types: String, Double, and Int
func printMyGenericType<T>(par: T) {
    print(" my \(T.self) is \(par)")
}

printMyGenericType(par: 6)
printMyGenericType(par: 6.75)
printMyGenericType(par: "'This is good'")


//MARK: - inout T type parameters:
func swappingGivenParamters<T>(a: inout T, b: inout T) {
    print("Before swapping:")
    print("a is \(a) & b is \(b)")
    
    let tempA = a
    a = b
    b = tempA
    print("After swapping:")
    print("a is \(a) & b is \(b)")
}


var a = 54
var b = 23
swappingGivenParamters(a: &a, b: &b)

var x = "Max"
var y = "Payne"
swappingGivenParamters(a: &x, b: &y)


//MARK: - Generics as a parameters:
func printStudentRanks<T, U>(name: U, rank: T) {
    print("\(name)'s and type of rank \(U.self) rank is \(rank.self) and type of rank \(T.self)")
}
printStudentRanks(name: "Bran", rank: 2)
printStudentRanks(name: "Dario", rank: 3)
printStudentRanks(name: "Paul", rank: "5")


//MARK: - Generic Struct
struct Emails {
    var mail: String
}
struct Messages {
    var msg: String
}
struct Emoji {
    var emoji: String
}
//Struct Generics
struct Container<T> {
    var list = [T]()
    
    mutating func addToList(item: T) {
        list.append(item)
    }
    mutating func emptyContainer() {
        self.list.removeAll()
    }
}

extension Container {
    var topItem: T? {
        if list.count > 0 {
            return list.last!
        }
        return nil
    }
}

///Note : The mutating keyword is used to change the struct’s or enum’s own properties. If any func trying to change its own type properties we need to use the mutating keyword just before the func definition.

var emailList = Container<Emails>()
emailList.addToList(item: Emails.init(mail: "Mail 1"))
emailList.addToList(item: Emails.init(mail: "Mail 2"))

let top = emailList.topItem
print(top?.mail ?? "Not There")

var messageList = Container<Messages>()
messageList.addToList(item: Messages.init(msg: "This is a message"))
let top1 = messageList.topItem
print(top1?.msg ?? "Msg Not There")

var emojiesList = Container<Emoji>()

emojiesList.addToList(item: Emoji.init(emoji: "🐯"))
emojiesList.addToList(item: Emoji.init(emoji: "👻"))
emojiesList.addToList(item: Emoji.init(emoji: "🦄"))

let topEmoji = emojiesList.topItem
print(topEmoji ?? "")


//MARK: - With Generic Constraints

class Book { }
protocol PDF { }
class SwiftBook: Book, PDF { }
class ObjcBook: Book { }
class KotlinBook: PDF { }
func printBookAvailableFormates<T: Book>(book: T) {
    print("The book is available only in paperback")
}


let objcBook = ObjcBook()
let kotlinBook = KotlinBook()
let swiftBook = SwiftBook()

printBookAvailableFormates(book: objcBook)
printBookAvailableFormates(book: swiftBook)
//printBookAvailableFormates(book: kotlinBook) ///Global function 'printBookAvailableFormates(book:)' requires that 'KotlinBook' inherit from 'Book'

func printBookAvailableFormates2<T: Book>(book: T) where T: PDF {
    print("The is available in paperback & PDF formats")
}

let objcBook2 = ObjcBook()
let kotlinBook2 = KotlinBook()
let swiftBook2 = SwiftBook()

printBookAvailableFormates2(book: swiftBook2)
//printBookAvailableFormates2(book: kotlinBook2)
//Global function 'printBookAvailableFormates2(book:)' requires that 'KotlinBook' inherit from 'PDF'




//MARK: - associated-type

class BookShop { }
class Book2 { }
protocol Shop {
    
    associatedtype Item
    var items: [Item]{ get set }
    
    mutating func addItem(item: Item)
    mutating func removeAll()
    
    func showAllItems() -> [Item]
}

extension BookShop: Shop {
    typealias Item = Book2
    var items: [Book2] {
        get {
            return self.items
        }
        set {
            self.items = newValue
        }
    }
    
    func addItem(item: Book2) {
            
    }
    func removeAll() {
        
    }
    func showAllItems() -> [Book2] {
        return items
    }
}



