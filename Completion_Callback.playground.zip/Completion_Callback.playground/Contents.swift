import UIKit


//MARK: - Methods With Completion Callback:

var shoppingList = ["key": "value"]


func callSomeMethodWithParameters(_ parameters: [AnyHashable: Any], onSuccess success: @escaping (_ JSON: Any) -> Void,
                                  onFailure failure: @escaping (_ error: Error?, _ parameters : [AnyHashable: Any]) -> Void
) {
    print("\n" + String(describing: parameters))
    let error: Error? = NSError(domain: "", code: 1, userInfo: nil)
    
    var responseArray: [Any]?
    responseArray = [1, 2, 3, 4, 5]

    if let responseArray = responseArray {
        success(responseArray)
    }
    if let error = error {
        failure(error, parameters)
    }
}

callSomeMethodWithParameters(shoppingList) { JSON in
    
    print("\nSuccess. Response received...: " + String(describing: JSON))

} onFailure: { error, parameters in
    
    if let error = error  {
        print("\nError: " + error.localizedDescription)
    }
    print("\nParameters passed are: " + String(describing: parameters))
    
}

